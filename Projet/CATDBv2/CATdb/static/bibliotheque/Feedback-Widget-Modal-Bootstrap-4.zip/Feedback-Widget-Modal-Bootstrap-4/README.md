# feedback_widget

## Description:
This widget demo basic structure for feedback using jquery, bootstrap.



[![](https://github.com/dhormale/feedback_widget/blob/master/feedback_jd.png)](https://github.com/dhormale/feedback_widget/blob/master/feedback_jd.png)
