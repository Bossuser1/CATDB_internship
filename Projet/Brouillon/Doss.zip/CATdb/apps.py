from django.apps import AppConfig


class CatdbConfig(AppConfig):
    name = 'CATdb'
